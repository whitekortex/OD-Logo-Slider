<?php
/**
 * Update version.
 */
update_option( 'logo_carousel_free_version', SP_LC_VERSION );
update_option( 'logo_carousel_free_db_version', SP_LC_VERSION );
